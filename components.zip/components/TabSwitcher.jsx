import React from 'react';
import { View, Pressable, Text, StyleSheet } from 'react-native';
import { hp, wp } from '../constants/helpers/common';
import { theme } from '../constants/theme';

export default function TabSwitcher({ 
  tabs,       // Array of { key: string, label: string }
  selected,   // currently selected tab key
  onSelect    // function to call with new key
}) {
  return (
    <View style={styles.container}>
      {tabs.map(tab => (
        <Pressable
          key={tab.key}
          style={[
            styles.tabButton,
            selected === tab.key && styles.tabButtonActive
          ]}
          onPress={() => onSelect(tab.key)}
        >
          <Text
            style={[
              styles.tabLabel,
              selected === tab.key && styles.tabLabelActive
            ]}
          >
            {tab.label}
          </Text>
        </Pressable>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row-reverse',
    justifyContent: 'flex-start',
    paddingHorizontal: wp(4),
    backgroundColor: theme.colors.background,
    marginBottom: hp(1),
  },
  tabButton: {
    paddingVertical: hp(1),
    paddingHorizontal: wp(4),
    marginHorizontal: wp(1),
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  tabButtonActive: {
    borderBottomColor: theme.colors.primary,
  },
  tabLabel: {
    color: theme.colors.textSecondary,
    fontSize: hp(2.2),
  },
  tabLabelActive: {
    color: theme.colors.textPrimary,
    fontWeight: '600',
  },
});
