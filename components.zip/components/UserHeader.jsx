// components/UserHeader.jsx
import React, { useEffect, useState } from 'react'
import { View, Text, Pressable, StyleSheet } from 'react-native'
import { Audio } from 'expo-av'
import { MotiView } from 'moti'
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons'
import Avatar from './Avatar'
import Icon from '../assets/icons'
import { hp, wp } from '../constants/helpers/common'
import { theme } from '../constants/theme'

export default function UserHeader({ user, router, onLogout }) {
  // העתק הלוגיקה שלך ל-playSound, calculateAge, renderTagList...
  return (
    <View style={styles.wrapper}>
      {/* כל ה־Avatar, Header title, editIcon, שורת הפרטים, Audio player, תגים וכו' */}
    </View>
  )
}

const styles = StyleSheet.create({
  /* העתק כאן את כל הסגנונות הרלוונטיים ל־UserHeader */
})
