export const theme = {
  colors: {
    // רקעים
    background: '#121212',        // רקע כללי כהה
    card: '#1E1E1E',              // כרטיסים / שדות
    surface: '#2C2C2E',           // קונטרסט ביניים

    // טקסטים
    textPrimary: '#FFFFFF',       // טקסט עיקרי על כהה
    textSecondary: '#CCCCCC',     // טקסט משני
    textTertiary: '#999999',      // טקסט חלש (placeholders)

    // צבעים ראשיים
    primary: '#E471A3',           // ורוד נעים עם ניגודיות טובה
    primaryDark: '#AD4D79',       // כהה יותר
    accent: '#FF88B2',            // צבע משלים - קליקבילי

    // הצללות/גבולות
    border: '#3A3A3C',
    shadow: '#00000080',

    // מצבים
    success: '#4CAF50',
    error: '#F44336',
    warning: '#FFC107',
    info: '#2196F3',
  },

  fonts: {
    medium: '500',
    semibold: '600',
    bold: '700',
    extraBold: '800',
  },

  radius: {
    xs: 8,
    sm: 12,
    md: 16,
    lg: 20,
    xl: 28,
    xxl: 36,
  }
};
